<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="/favicon.ico" type="image/x-icon" />

<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css" />


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/m-style.css" />
<link rel="stylesheet" type="text/css" href="assets/css/style.css" />
<link href="https://fonts.googleapis.com/css?family=Niramit:200,200i,300,300i,400,400i,500,500i,600,600i,700,700i|Titillium+Web:200,200i,300,300i,400,400i,600,600i,700,700i,900" rel="stylesheet">
<!--[if IE]>
  <script src="<?php echo $basesurl;?>js/html5.js"></script>
<![endif]-->


