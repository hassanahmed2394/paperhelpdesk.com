<section class="bottom-form">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="txtwrap">
          <h2>Join the Reseller Prohub partners community </h2>
         
          <p>Reseller Prohub is eager to partner up with highly-motivated individuals or firms looking to increase their revenues significantly. Partnering with Reseller Prohub will provide you the unique ability to offer or resell high-quality design, Internet marketing, SEO, video animation, logo design, eCommerce solutions, brand guide and mobile app development services to your customers. </p>
        </div>
      </div>
      <div class="col-lg-6">
        <?php
        $btmformfields = $_SERVER['HTTP_HOST']; 
        $btmformfields = $srcurl."btmformfields.php"; 
        include_once($btmformfields); 
        ?>
      </div>
    </div>
  </div>
</section>